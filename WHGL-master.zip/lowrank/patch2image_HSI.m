function y=patch2image_HSI(f,px,py,mi,ni,Bi)

me=px+mi;
ne=py+ni;

fe=zeros(me,ne,Bi);
w=zeros(me,ne,Bi);

for ii= 1:px
    for jj= 1:py
        fe(ii:ii+mi-1,jj:jj+ni-1,:) = fe(ii:ii+mi-1,jj:jj+ni-1,:)+reshape(f(:,px*py*(0:(Bi-1))+(jj-1)*px+ii),mi,ni,Bi);
        w(ii:ii+mi-1,jj:jj+ni-1,:) = w(ii:ii+mi-1,jj:jj+ni-1,:)+1;
    end
end

w=w(1:mi,1:ni,1:Bi);
fe=fe(1:mi,1:ni,1:Bi);


if(sum(sum(sum(w<1/2)))>0)
    fprintf('patches do not cover the image.\n')
    y=0;
    return;
end

y=fe./w;
