  %addpath('PROPACKmod/');
  %addpath('solver');
  %load data_5_syn
  [m,n,B] = size(Hw);
  px=2;
  py=2;
  Hw_reshape = image2patch_HSI(Hw,px,py);
  id_matrix_2d = logical(image2patch_HSI(id_matrix_v,px,py));


%%
  Bi=B;
  problem_type = 'NNLS'; 
  %%problem_type = 'SDLS'; 
  scenario = 'noiseless';  
  %%scenario = 'noisy'; 
%%
  randstate=1;
      [nr,nc]=size(Hw_reshape);  
      p=nnz(id_matrix_2d);
      M=Hw_reshape;
      normM=norm(M,'fro');
      prob = p/(nr*nc); 
      [II,JJ]=find(id_matrix_2d);
      bb=Hw_reshape(id_matrix_2d);
      Jcol = compJcol(JJ); 
      B  = spconvert([II,JJ,bb; nr,nc,0]); 
      xi = sparse(p,1); 
      sigma = 0; 
      [II,JJ,bb] = find(B);
      Jcol = compJcol(JJ);  
         %%------------------------------------------------
         %% evaluate the regularization parameter mu
         %%
         options.tol = 1e-8; 
         mumax = svds(sparse(B),1,'L',options);
         mu_scaling = 1e-15;   %1e-4 originally, 1e-15 for noiseless
         mutarget   = mu_scaling*mumax;
         noiseratio = norm(xi)/norm(bb); 
         %%
         fprintf('\n Problem: nr = %d, nc = %d,',nr,nc); 
         fprintf('\n mu = %3.2e, noise ratio, sigma = %3.2e, %3.2e',...
                 mutarget,noiseratio,sigma); 
         tstart = clock;
         Amap  = @(X) Amap_MatComp(X,II,Jcol);
         if (exist('mexspconvert')==3); 
            ATmap = @(y) mexspconvert(nr,nc,y,II,Jcol); 
         else
            ATmap = @(y) spconvert([II,JJ,y; nr,nc,0]); 
         end
         par.tol     = 1e-3;
         
         par.verbose = 1;
         par.truncation_start = 10; 
         par.continuation_scaling = mu_scaling;
         [X,iter,time,sd,hist] = ...
            APGL(nr,nc,problem_type,Amap,ATmap,bb,mutarget,0,par);
         if isstruct(X)
            normX = sqrt(sum(sum((X.U'*X.U).*(X.V'*X.V))));
            trXM = sum(sum(X.U.*(M*X.V)));
         else
            normX = norm(X,'fro'); trXM = sum(sum(M.U.*(X*M.V))); 
         end
         mse = sqrt(normX^2+normM^2-2*trXM)/normM;
         runhist.mu(randstate)     = mutarget; 
         runhist.mumax(randstate)  = mumax; 
         runhist.time(randstate)   = etime(clock,tstart);
         runhist.iter(randstate)   = iter;
         runhist.obj(randstate)    = hist.obj(end);
         runhist.mse(randstate)    = mse; 
         runhist.svp(randstate)    = hist.svp(end);
         runhist.maxsvp(randstate) = max(hist.svp); 
         runhist.maxsig(randstate) = max(sd); 
         runhist.minsig(randstate) = min(sd(find(sd>0)));
         %%
         %% report results in a table
         %%
         fprintf(' Problem: nr = %d, nc = %d,',nr,nc); 
         fprintf('\n mu = %3.2e, noise ratio, sigma = %3.2e, %3.2e',...
                  mutarget,noiseratio,sigma)
         fprintf('\n-----------------------------------------------');
         fprintf('------------------------------')
         fprintf('\n problem type       :  %s',problem_type);
         fprintf('\n randstate          :  %6.0f',randstate);
         fprintf('\n iterations         :  %6.0f',runhist.iter(randstate));
         fprintf('\n # singular         :  %6.0f',runhist.svp(randstate));
         fprintf('\n obj  value         :  %6.5e',runhist.obj(randstate));
         fprintf('\n cpu   time         :  %6.2e',runhist.time(randstate));
         fprintf('\n mean square error  :  %6.2e',runhist.mse(randstate));
         fprintf('\n------------------------------------------------'); 
         fprintf('------------------------------\n')

%%*************************************************************************

%{
temp=X.U*X.V';
temp=patch2image_3d(temp,x1,x2,x3,px,py,pz,m,n,162);
imagesc(temp(:,:,100),[0,1000])
colormap jet
%}
% for kiwi
temp=X.U*X.V';
result_lowrank=patch2image_HSI(temp,px,py,m,n,Bi);

%temp=patch2image_3d(temp,x1,x2,x3,px,py,pz,m,n,146);
%imagesc(temp(:,:,100))
%colormap jet

%{
temp=X.U*X.V';
imagesc(reshape(temp(:,10),150,150),[0,1000])
colormap jet
%}