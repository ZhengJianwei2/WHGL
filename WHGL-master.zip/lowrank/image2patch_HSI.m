function y=image2patch_HSI(f,px,py)

pad_f = padarray(f,[px,py],'symmetric','post');
[m,n,B] = size(f);

y=zeros(m*n,px*py*B);

for ii=1:px
    for jj=1:py
        y(:,px*py*(0:(B-1))+(jj-1)*px+ii)= reshape(pad_f(ii:ii+m-1,jj:jj+n-1,:),m*n,B);
    end
end


