bands_kept=setdiff(1:162,bands_removed);
result=zeros(150,150,162);
result(:,:,bands_kept)=temp;
[m,n,B]=size(result);
for i=1:m
    for j=1:n
        temp=result(i,j,:);
        y=temp(:);
        x=1:B;
        x(bands_removed)=[];
        y(bands_removed)=[];
        xx=1:B;
        yy=spline(x,y,xx);
        result(i,j,:)=yy;
    end
end
psnr=zeros(2,length(bands_removed));
for i=1:length(bands_removed)
    psnr(1,i)=bands_removed(i);
    temp=sum(sum((result(:,:,i)-Hw(:,:,i)).^2))/150/150;
    psnr(2,i)=10*log(1^2/temp)/log(10);
end
avgpsnr=mean(psnr(2,:));