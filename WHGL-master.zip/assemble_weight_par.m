function W_new=assemble_weight_par(W,px,py,m,n)
% This computes the weight in a parallelized way
r=m*n;
W_new=sparse(r,r);
W_new_cell=cell(py,1);
W_cell=cell(py,1);
for i=1:py
    W_new_cell{i}=sparse(r,r);
    W_cell{i} = W;
end
parfor jj=1:py
    major_idx = (1:r)';
    for kk=1:jj-1
        major_idx=major_swap(major_idx,m,n);
    end
    for ii=1:px
        if ii==1
            idx=major_idx;
        else
            idx=minor_swap(idx,m,n);
        end
        left=sparse(1:r,idx,1,r,r);
        right=sparse(idx,1:r,1,r,r);
        W_temp=left*W_cell{jj}*right;
        %{
        W_temp(:,1:r)=W_temp(:,idx);
        toc
        tic
        W_temp(1:r,:)=W_temp(idx,:);
        toc
        %}
        W_new_cell{jj}=W_new_cell{jj}+W_temp;
    end
end
for i=1:py
    W_new=W_new+W_new_cell{i};
end