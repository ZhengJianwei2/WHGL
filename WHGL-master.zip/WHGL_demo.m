close all
clear
clc
run vlfeat-0.9.21/toolbox/vl_setup
% % addpath('HSI_LDMM');
addpath('lowrank');
addpath('lowrank/PROPACKmod/');
addpath('lowrank/solver');
addpath('assess_fold');
addpath('data');

WHGL = 1;

for tensor_num=1
    switch tensor_num
        case 1
            load data/Pavia_80
%           path = 'E:\paper\my paper\WHGL\code_WNSR\result\pavia_80\';
            pic='PAV';
        case 2
            load data/DCmall.mat 
%             load data/WDC.mat 
%             Hw=WDC(:,:,1:100);
%           path = 'E:\paper\my paper\WHGL\code_WNSR\result\wdc\';
            pic='WDC';
        case 3            
            load data/pavia_university.mat
%            path = 'E:\paper\my paper\WHGL\code_WNSR\result\pavia_university\';
            pic='Unv';
        case 4  
            load data/video.mat
%           path = 'E:\paper\my paper\WHGL\code_WNSR\result\video0.2\';  
            Hw=T/max(T(:)); 
    end

for Ra= 1
    switch Ra
        case 1
            rate = .05;
        case 2
            rate = .1;
        case 3
            rate = .15;
        case 4
            rate = .2;
        case 5
            rate = .25;
    end    
    [m,n,BB] = size(Hw);
    y=Hw;
%% sample
    id_matrix_v=zeros(m,n,BB);
    for j=1:BB
        id1 = randperm(m*n);
        id = id1(1:floor(m*n*rate));%1*40000*0.15
        id_matrix=zeros(m,n);%256*256
        id_matrix(id)=1;
        id_matrix_v(:,:,j)=id_matrix;
    end
    y=y.*id_matrix_v;

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %     % low rank initialization
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    t1=clock;
    test_lowrank
    t2=clock;
% %     [psnr_lr,ssim_lr,sam_lr,mq_lr]=evaluate(Hw,result_lowrank,m,n);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % ldmm refinement
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    gamma=5;  
    mu=gamma-1;
    ms = 25;
    ms_normal=floor(ms/2);
    scale_target=0;
    outerloop=1;                                % 1 iteration of ldmm
    lambda = 1e8;  % data fidelity
    beta=0.05;
    px=1;                                       % patch size
    py=1;
% % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% WNSR %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if WHGL
    name = 'WHGL';
    t1=clock; 
    [result_whgl] = WHGL_WGL_noisy_HSI(y,id_matrix_v,mu,lambda,outerloop,px,py,ms,...
    ms_normal,Hw,scale_target,result_lowrank,name,gamma,beta);
    t2=clock;

    time_whgl=etime(t2,t1);
    [psnr_whgl,ssim_whgl,sam_whgl,mq_whgl]=evaluate(Hw,result_whgl,m,n);

     Index_whgl(1)=roundn(psnr_whgl,-4);Index_whgl(2)=roundn(ssim_whgl,-4);Index_whgl(3)=roundn(sam_whgl,-4);Index_whgl(4)=roundn(time_whgl,-4);
% save([path,'result_' num2str(rate) '_' name '.mat'],'result_wnsr','psnr_wnsr','ssim_wnsr','time_wnsr','sam_wnsr');%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    end

end
end